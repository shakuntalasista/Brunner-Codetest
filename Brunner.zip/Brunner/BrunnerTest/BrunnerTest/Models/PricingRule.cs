﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BrunnerTest.Models
{
    public class PricingRule
    {
        public string ItemName { get; set; }
        public int ItemCount { get; set; }
        public double TotalCost { get; set; }
       
    }
}