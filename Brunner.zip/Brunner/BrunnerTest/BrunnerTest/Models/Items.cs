﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BrunnerTest.Models
{
    public class Items
    {
        public string ItemName { get; set; }
        public double ItemCost { get; set; }
        
    }
}