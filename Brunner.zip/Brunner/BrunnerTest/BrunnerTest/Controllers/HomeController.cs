﻿using BrunnerTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BrunnerTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly List<Items> items = new List<Items>();
        private readonly List<PricingRule> pricingRules = new List<PricingRule>();

        private void defineItemsAndPricingRules() {
            Items item1 = new Items();
            item1.ItemName = "Apples";
            item1.ItemCost = 0.45;
            items.Add(item1);

            Items item3 = new Items();
            item3.ItemName = "Apples";
            item3.ItemCost = 0.45;
            items.Add(item3);

            Items item2 = new Items();
            item2.ItemName = "Oranges";
            item2.ItemCost = 0.65;
            items.Add(item2);

            Items item4 = new Items();
            item4.ItemName = "Oranges";
            item4.ItemCost = 0.65;
            items.Add(item4);

            Items item5 = new Items();
            item5.ItemName = "Oranges";
            item5.ItemCost = 0.65;
            items.Add(item5);

      
            PricingRule rule1 = new PricingRule();
            rule1.ItemName = "Apples";
            rule1.ItemCount = 2;
            rule1.TotalCost = 0.45;
            pricingRules.Add(rule1);

            PricingRule rule2 = new PricingRule();
            rule2.ItemName = "Oranges";
            rule2.ItemCount = 3;
            rule2.TotalCost = 1.3;
            pricingRules.Add(rule2);
        }
        public ActionResult Index()
        {
            //pass list of string as input

            defineItemsAndPricingRules();
            return View(items);
        }

      
        public JsonResult CalculateTotal()
        {
            double finalprice = 0;
            defineItemsAndPricingRules();
            var itemGroups = items.GroupBy(g => g.ItemName);
            if (pricingRules != null)
            foreach (var itemGroup in itemGroups)
            {

                    var ruleForGroup = pricingRules.FirstOrDefault(pr => pr.ItemName == itemGroup.Key);
                if (ruleForGroup != null)
                {
                    var groupCount = itemGroup.Count();

                    var extra = groupCount - ruleForGroup.ItemCount;
                    if (extra < 0)
                    {
                        finalprice += itemGroup.Sum(g => g.ItemCost);
                        
                    }
                    else
                    {
                        finalprice += ruleForGroup.TotalCost;
                        finalprice += extra * itemGroup.First()
                                                .ItemCost;

                    }
                }
                else
                {
                    finalprice += itemGroup.Sum(x => x.ItemCost);
                }
            }

            return Json(finalprice);
        }

    }
}